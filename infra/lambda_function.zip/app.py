import boto3
import os
from datetime import datetime, timezone

# This function name MUST match the Terraform handler: app.Happy_new_year
def Happy_new_year(event, context):
    iam = boto3.client('iam')
    ses = boto3.client('ses')
    
    # Logic to send the email with the link to your new portal
    target_user = 'vishnu.ksouri121212@gmail.com'
    sender = os.environ.get('SENDER_EMAIL')
    
    print(f"--- Starting Daily Security Audit for: {target_user} ---")

    try:
        response = iam.list_access_keys(UserName=target_user)
        for key in response['AccessKeyMetadata']:
            # ... (rest of your audit logic)
            print(f"Key Found: {key['AccessKeyId']}")
            
            # The email body now points to your portal instruction
            subject = "ACTION REQUIRED: Access Your Secure Analyze Folder"
            body = f"Your Access Key is {key['AccessKeyId']}. Use this in the Portal app to access S3."
            
            ses.send_email(
                Source=sender,
                Destination={'ToAddresses': [target_user]},
                Message={'Subject': {'Data': subject}, 'Body': {'Text': {'Data': body}}}
            )
        
        return {'statusCode': 200, 'body': 'Audit completed successfully'}
    except Exception as e:
        print(f"Error: {str(e)}")
        return {'statusCode': 500, 'body': str(e)}
